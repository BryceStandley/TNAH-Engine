--input.lua
--6/04/21 Christopher Logan
foward = 87;
back = 83;
left = 65;
right = 68;
toggle = 75;
exit = 88;
