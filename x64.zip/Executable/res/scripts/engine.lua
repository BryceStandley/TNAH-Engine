--engine.lua
--6/04/21 Christopher Logan
width = 720;
height = 1280;
name = "ICT397 - Game Engine";
amount = 1;

