--skybox.lua
right = "./res/images/skybox/right.jpg"
left = "./res/images/skybox/left.jpg"
top = "./res/images/skybox/top.jpg"
bottom = "./res/images/skybox/bottom.jpg"
front = "./res/images/skybox/front.jpg"
back = "./res/images/skybox/back.jpg"
vs = "./res/shader/skybox_vert.glsl"
fs = "./res/shader/skybox_frag.glsl"